import{X as a}from"./BJJP7Q0Q.js";a();
