import{l as o,a as r}from"../chunks/BM_FI7Wk.js";export{o as load_css,r as start};
