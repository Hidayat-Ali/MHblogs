import{t as o,b as p}from"../chunks/BJOssxvh.js";import"../chunks/BCrd3Tvo.js";var e=o("<h1>this is contact page!</h1>");function i(t){var a=e();p(t,a)}export{i as component};
