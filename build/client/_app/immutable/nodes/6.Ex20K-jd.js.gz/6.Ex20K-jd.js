import{t as o,b as p}from"../chunks/BGAgWMwB.js";import"../chunks/cbcU0EHI.js";var e=o("<h1>this is contact page!</h1>");function i(t){var a=e();p(t,a)}export{i as component};
